1.Credit card fraud detection
  - dataset : https://drive.google.com/file/d/1CTAlmlREFRaEN3NoHHitewpqAtWS5cVQ/view

2.Character recognition
  - dataset : https://www.kaggle.com/datasets/sachinpatel21/az-handwritten-alphabets-in-csv-format
